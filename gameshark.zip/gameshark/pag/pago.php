<div class="container-fluid" id="seccion_targeta" style="padding: 20px 10px 0px 20px;">
  <div class="mx-auto" style="width: 900px;">
    <div class="row">
      <div class="col-12">
        <h2>
          Ingrese los datos de su tarjeta de crédito
        </h2>
      </div>
      <div class="col-12 borde">
        <label style="display: block !important;">
          Nombre
        </label>
        <div class="input-group">
          <input aria-label="Text input with dropdown button" class="form-control" id="nombre_usuario_targeta" type="text"/>
        </div>
        <label style="display: block !important;">
          Correo electrónico
        </label>
        <div class="input-group">
          <input aria-label="Text input with dropdown button" class="form-control" id="correo" type="text"/>
        </div>
        <label style="display: block !important;">
          Número de la tarjeta.
        </label>
        <div class="input-group">
          <input aria-label="Text input with dropdown button" class="form-control" type="text"/>
        </div>
        <label style="display: block !important;">
          Fecha de expiración
        </label>
        <div class="input-group">
          <input aria-label="Text input with dropdown button" class="form-control" type="date"/>
        </div>
        <label style="display: block !important;">
          Código de seguridad
        </label>
        <div class="input-group">
          <input aria-label="Text input with dropdown button" class="form-control" type="text"/>
        </div>
        <input class="btn btn-success" id="btnvisa" type="button" value="enviar"/>
      </div>
    </div>
  </div>
</div>
