function visa_hide(argument) {
    let btn_visa = document.getElementById("btnvisa");

}