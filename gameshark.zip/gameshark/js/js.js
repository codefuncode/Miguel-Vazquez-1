
borracampos();


getdata();
guardar();

devuelveinventario();
