<?php

//  Inicio de la aplicación
header("Location: pag/inicio.php");
