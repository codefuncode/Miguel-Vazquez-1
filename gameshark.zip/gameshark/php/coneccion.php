 <?php


//variables para establecer la conección con la base de datos cuando esta en un servidor.



 //$servername = "sql313.epizy.com;port=3306";
 //$username   = "epiz_28022149";
 //$password   = "81m5pzn2";
 //$dbname     = "epiz_28022149_gameshark";

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "gameshark";
?>
